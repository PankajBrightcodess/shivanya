<?php
	// define("API_KEY","rzp_test_RT0gbZ74mNgXBK");
	define("API_KEY","rzp_test_9bDn1xgVwuogYt");
	// define("API_KEY","rzp_live_ESJiSGIEkrg68p");
	// define("API_KEY","rzp_test_KVV2yNPLssjS3jUvH171bc3x");
	
?>